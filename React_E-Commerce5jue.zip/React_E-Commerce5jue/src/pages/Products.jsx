import React from 'react';
import { Footer, Navbar, Product } from '../components';

const Products = () => {
	return (
		<>
			<Product />
		</>
	);
};

export default Products;
